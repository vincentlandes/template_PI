﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Diagnostics;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;

namespace Template {

class Game
{
	public Surface screen;
	static double hit = 0, miss = 0;
	static double elapsed;
	static int samples = 0, samplesPerFrame = 1000;
	static RNGCryptoServiceProvider rng;
	static Stopwatch timer;
	static double GetRandomNumber()
	{
		// get a random number in the range -1..1
		byte[] data = new byte[4];
		rng.GetBytes( data );
		uint value = BitConverter.ToUInt32( data, 0 );
		return 2.0 * (double)value / (65536.0 * 65536.0) - 1.0;
	}
	public void Init()
	{
		rng = new RNGCryptoServiceProvider();
		timer = new Stopwatch();
		timer.Start();
		screen.Clear( 0x2222ff );
	}
	public void Tick()
	{
		if (samples < 1000000)
		{
			// sample the disc randomly
			for( int i = 0; i < samplesPerFrame; i++ )
			{
				double x = GetRandomNumber();
				double y = GetRandomNumber();
				double d = x * x + y * y;
				int ix = (int)((x + 1) * screen.width) / 3 + screen.width / 6;
				int iy = (int)((y + 1) * screen.height) / 3 + screen.height / 6;
				if (d > 1) 
				{
					miss += 1.0; 
					screen.Plot( ix, iy, 0 );
				}
				else 
				{
					hit += 1.0;
					screen.Plot( ix, iy, 0xff0000 );
				}
			}
			samples += samplesPerFrame;
			elapsed = timer.Elapsed.TotalMilliseconds / 1000.0;
		}
		// estimate pi
		double pi = hit / (hit + miss) * 4;
		// print pi
		int bx1 = screen.width / 6;
		int by1 = screen.height - screen.height / 7;
		string s = "E = " + pi.ToString();
		screen.Bar( bx1, by1, bx1 + 300, by1 + 60, 0x2222ff );
		screen.Print( s, bx1, by1, 0xffffff );
		// print sample count and time
		s = samples.ToString() + " in " + elapsed.ToString() + " sec";
		screen.Print( s, bx1, by1 + 30, 0xffffff );
	}
	public void Render()
	{
		// render stuff over the backbuffer (OpenGL, sprites)
	}
}

} // namespace Template
